# Drag and drop placeholder on PDF documents with mozilla pdf.js, interact.js, boostrap 3 and jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/ValerioEmanuele/pen/pGRZqe](https://codepen.io/ValerioEmanuele/pen/pGRZqe).

In this example I'll show you how to drag and drop placeholders into PDF documents and convert the HTML placeholders coordinates in PDF coordinates (itext PDF).